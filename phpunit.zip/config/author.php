<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Company/Author/Developer/Licence information of the application
    |--------------------------------------------------------------------------
    |
    | All details about the author/developer/contact/licence of the application
    |
    | IMPORTANT: CHANGING ANY OF THIS INFORMATION WILL UNSTABILIZE THE APPLICATION
    |
    */

    'vendor' => 'Megacom',
    'vendor_url' => 'http://megacomsolutions.com.com',
    'email' => 'cto@megacomsolutions.com',
    'app_version' => '6.3',
    'lic1' => 'aHR0cHM6Ly9tZWdhY29tc29sdXRpb25zLmNvbS9hcGkvdHlwZV8x',
    'pid' => 1,
    'license_code' => env('LICENSE_CODE', 0),
];
