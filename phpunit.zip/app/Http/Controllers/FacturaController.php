<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
require 'vendor/autoload.php';  // Asegúrate de que autoload.php esté en la ubicación correcta
use Afip;

class FacturaController extends Controller
{
    public function crearFactura(Request $request)
    {
        // Validar los datos recibidos desde el frontend
        $data = $request->validate([
            'invoice_type' => 'required|integer',
            'invoice_concept' => 'required|integer',
            'buyer_document_type' => 'required|integer',
            'buyer_document_number' => 'required|integer',
            'transaction_date' => 'required|date',
            'denomination_total_amount' => 'required|numeric',
            'start_date' => 'required|date',
            'end_date' => 'required|date',
            'payment_due_date' => 'required|date',
        ]);

        // Extraer los datos del request
        $invoice_type = $data['invoice_type'];
        $invoice_concept = $data['invoice_concept'];
        $buyer_document_type = $data['buyer_document_type'];
        $buyer_document_number = $data['buyer_document_number'];
        $transaction_date = $data['transaction_date'];
        $denomination_total_amount = $data['denomination_total_amount'];
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];
        $payment_due_date = $data['payment_due_date'];

        // Crear la instancia de AFIP dentro del método
        $afip = new Afip(array('CUIT' => 20409378472));

        try {
            // Obtener el último número de factura
            $last_voucher = $afip->ElectronicBilling->GetLastVoucher(1, $invoice_type);  // Punto de venta 1

            // Obtener el número de factura y aumentar 1
            $numero_de_factura = $last_voucher['CbteDesde'] + 1;

            // Configurar las fechas para el servicio y vencimiento de pago
            if ($invoice_concept === 2 || $invoice_concept === 3) {
                $fecha_servicio_desde = intval(str_replace('-', '', $start_date));
                $fecha_servicio_hasta = intval(str_replace('-', '', $end_date));
                $fecha_vencimiento_pago = intval(str_replace('-', '', $payment_due_date));
            } else {
                $fecha_servicio_desde = null;
                $fecha_servicio_hasta = null;
                $fecha_vencimiento_pago = null;
            }

            // Preparar los datos para la factura
            $invoice_data = [
                'CantReg'    => 1,
                'PtoVta'    => 1,  // Punto de venta
                'CbteTipo'    => $invoice_type,
                'Concepto'    => $invoice_concept,
                'DocTipo'    => $buyer_document_type,
                'DocNro'    => $buyer_document_number,
                'CbteDesde' => $numero_de_factura,
                'CbteHasta' => $numero_de_factura,
                'CbteFch'    => intval(str_replace('-', '', $transaction_date)),
                'FchServDesde' => $fecha_servicio_desde,
                'FchServHasta' => $fecha_servicio_hasta,
                'FchVtoPago'   => $fecha_vencimiento_pago,
                'ImpTotal'    => $denomination_total_amount,
                'ImpTotConc'  => 0,
                'ImpNeto'    => $denomination_total_amount,
                'ImpOpEx'    => 0,
                'ImpIVA'    => 21,  // Suponiendo una alícuota del 21%
                'ImpTrib'    => 0,
                'MonId'    => 'PES',  // Moneda: Pesos Argentinos
                'MonCotiz'    => 1,  // Cotización
                'Iva'    => [
                    [
                        'Id'        => 5,  // 21% IVA
                        'BaseImp'    => $denomination_total_amount,
                        'Importe'    => $denomination_total_amount * 0.21,  // IVA calculado al 21%
                    ]
                ],
            ];

            // Llamar a la API de AFIP para crear la factura
            $res = $afip->ElectronicBilling->CreateVoucher($invoice_data);

            // Retornar la respuesta (CAE y fecha de vencimiento)
            return response()->json([
                'cae' => $res['CAE'],
                'vencimiento' => $res['CAEFchVto'],
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Hubo un error al generar la factura: ' . $e->getMessage(),
            ]);
        }
    }
}
